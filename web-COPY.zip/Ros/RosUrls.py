from django.urls import path

from Ros import RosView

urlpatterns = [
    path('room/<str:room_name>/', RosView.room, name='room'),
]
