from django.core.paginator import Paginator
from django.shortcuts import render, get_object_or_404
from django.db.models import Q, Count
from ..models import Question
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.request import Request
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny




# def index(request):
    
#     # return HttpResponse("아직이야")
#     #context={}
#     return render(request, 'testcarapp/room.html')

def index(request):
    
    # return HttpResponse("아직이야")
    #context={}
    return render(request, 'testcarapp/map.html')


