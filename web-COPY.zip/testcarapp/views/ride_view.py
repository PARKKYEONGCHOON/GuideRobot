from ast import Store
from pydoc import resolve
from re import template
from certifi import contents
from django.shortcuts import redirect, render, resolve_url
# Create your views here.

from tempfile import tempdir
from django.http import HttpRequest, HttpResponse
from django.template import loader 
import datetime #시간
	
import os
import json
from django.conf import settings #세팅 임포트 해주기
from ..models import * 

from django.db.models import Avg  #6/17 

# UTC +9:00 의 한국 시간의 타임존 생성
KST = datetime.timezone(datetime.timedelta(hours=9)) #6/14

rideList=[]  #빈리스트로 전역변수로 정의
with open(os.path.join(settings.BASE_DIR,'static/lotte_world_tt.json'))as file:  
    jsonData=json.load(file)
    rideList.clear()
    rideList += jsonData['rideList']



def index(request:HttpRequest):
    template=loader.get_template('ride.html')

    rides = []
    rideObjs = Ride.objects.all()
    print('rideObjs:',rideObjs)


    for index,ride in enumerate(rideObjs):
        print('ride:',ride)
         

        detail:str = ride.detail #!!!!
        detail = detail.replace('\\n', '\n')
        print('ride.detail:',detail)

        ri = {
            'id' : ride.pk,

            'color' : ride.color, #6/15 
            'name' : ride.name,
            'detail' : detail,
            'thumbnail' : ride.thumbnail,
            'explain' : ride.explain,
            'height' : ride.height,
            'rating' : ride.rating,
        }
        rides.append(ri)
    
    context={"rides":rides}
    return HttpResponse(template.render(context,request))
  


def lotte(request:HttpRequest):
    template=loader.get_template('lotte_tt.html')
    context={}
    return HttpResponse(template.render(context,request))
  
colorMap = [   #614
    '#ff0000', #레드
    '#00ff00', #그린
    '#0000ff', #블루
]




def ride_detail(request:HttpRequest,ride_id:str):       
    #방어로직 (예외처리)

    if ride_id is None:
        return HttpResponse('접근이 잘못 되었습니다')
    

    rideObj = Ride.objects.get(pk = ride_id)   #하나의 항목 pk로 불러옴
    print('rideObj',rideObj)

    #UTC 표준 시간 00:00 한국은 +9시


    createTime:datetime.datetime = rideObj.createTime
    print('createTime : ',createTime)
    # print('createTime : ',type(createTime))

    createTimestr = createTime.strftime('%Y-%m-%d %H:%M:%S')
                         #년-월-일 시:분:초
    print('createTimestr : ', createTimestr)                     


    
    comments = []

    commentsObjs = Comment.objects.filter(ride=rideObj).order_by('-pk') #내림차순정렬 (.order_by('pk'))
    for comment in commentsObjs:


        createTimestr = comment.createTime.astimezone(KST).strftime('%Y-%m-%d %H시%M분%S초') 
        #6/14
        # constents:str = comment.message #줄
        # # print('before contents:',contents)
        # constents = constents.replace('\\n','\n') #줄
        # # print('after contents:',contents)
        

        print('comment:',comment)
        co = {
            'id':comment.pk, #특정코멘트 지우기위해..
            'authorName':comment.authorName,
            'message':comment.message,
            'createTime':createTimestr,
            'rating':comment.rating
        }
        comments.append(co)
        print('createTime:',comment.createTime)


        # commentList.append({
        #     'id':comment.pk, ##tjstodsla..
        #     'authorName':comment.authorName,
        #     'message':comment.message,
        #     'createTime':createTimestr,
        #     'rating':comment.rating
        # })
        # template = loader.get_template('lotte_tt.html')
        # context={
        # "ri":rideData,
        # "commentList": commentList #♣
        # }      #키값은 변수 이름
        # return HttpResponse(template.render(context,request))



    explain:str = rideObj.explain #줄
    # print('before contents:',contents)
    explain = explain.replace('\\n','\n') #줄
    # print('after contents:',contents)
    



    rideData = {
            'id' : rideObj.pk,
            'name' : rideObj.name,
            'thumbnail' : rideObj.thumbnail,
            'explain' : explain,
            'height' : rideObj.height,
            # 'address' : rideObj.address,
            # 'distance' : rideObj.distance,
            'rating' : rideObj.rating,
            
    }

    # template=loader.get_template('lotte_tt.html')
    # context={"ri":rideData}   #키값은 변수 이름
    # return HttpResponse(template.render(request,context))

    # template = loader.get_template('lotte_tt.html')
    context={
        "ri":rideData,
        "commentList": comments  #♣
    }   #키값은 변수 이름
    return HttpResponse(render(request,'lotte_tt.html',context))


def commentWrite(request:HttpRequest,ride_id):
    
    redirectUrl = resolve_url('testcarapp:ride_detail',ride_id)
    
    if(request.method == 'POST'):
        # body = request.body
        # print('commentWrite:: body:',body)


        try:

            authorName = request.POST['name'] 
            contents = request.POST['contents']

            rating = request.POST['rating']
            print('commentWrite:: authorName:', authorName)
            print('commentWrite:: contents:',contents)  

            
             

            ride = Ride.objects.get(pk = ride_id)

            comment = Comment()
            comment.ride = ride
            comment.authorName = authorName
            comment.authorThumbnail = ''
            comment.message = contents
            comment.rating = rating
            
            # comment.createTime = 4

            comment.save()

            #6/17
            avgRating=Comment.objects.filter(ride=ride).aggregate(Avg('rating')) #6/17
            # Ride.objects.get(pk=ride_id).update(rating = avgRating)
            ride.rating = avgRating['rating__avg']
            ride.save()

            redirectUrl+= '#comment-write'
        except:
            pass

# f' resolve_url('turtle:ride_detail')}


    # redirectUrl = f"{resolve_url('turtle:ride_detail',ride_id)}#comment-write"
                                    #경로 불러와       ride/detail/1(ride_id) +
              # = {resolve_url('turtle:ride_detail',ride_id)} + '#comment-write'
    print('redirectUrl:',redirectUrl)

    return redirect(redirectUrl)    




#6/14
def commentDelete(request:HttpRequest,ride_id,comment_id): #특정코멘트
    
    redirectUrl = resolve_url('testcarapp:ride_detail',ride_id)
    
    if(request.method == 'POST'):
        try:
            Comment.objects.get(pk=comment_id).delete()
            
            #6/17
            ride:Ride = Ride.objects.get(pk=ride_id)   
            avgRating=Comment.objects.filter(ride=ride).aggregate(Avg('rating'))
            ride.rating=avgRating('rating__avg')
            ride.save()

            redirectUrl+= '#comment-write'
        except:
            pass
    print('redirectUrl:',redirectUrl)

    return redirect(redirectUrl)    