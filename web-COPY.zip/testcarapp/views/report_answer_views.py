from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, get_object_or_404, redirect, resolve_url
from django.utils import timezone

from ..forms import report_AnswerForm
from ..models import report_Question, report_Answer


@login_required(login_url='common:login')
def answer_create(request, question_id):
    """
    pybo 답변등록
    """
    question = get_object_or_404(report_Question, pk=question_id)
    if request.method == "POST":
        form = report_AnswerForm(request.POST)
        if form.is_valid():
            answer = form.save(commit=False)
            answer.author = request.user  # author 속성에 로그인 계정 저장
            answer.create_date = timezone.now()
            answer.question = question
            answer.save()
            #return redirect('testcarapp:detail', question_id=question.id)
            return redirect('{}#answer_{}'.format(
                resolve_url('testcarapp:reportdetail', question_id=question.id), answer.id))
    else:
        form = report_AnswerForm()
    context = {'question': question, 'form': form}
    return render(request, 'testcarapp/report_question_detail.html', context)  


@login_required(login_url='common:login')
def answer_modify(request, answer_id):
    """
    pybo 답변수정
    """
    answer = get_object_or_404(report_Answer, pk=answer_id)
    if request.user != answer.author:
        messages.error(request, '수정권한이 없습니다')
        return redirect('testcarapp:detail', question_id=answer.question.id)

    if request.method == "POST":
        form = report_AnswerForm(request.POST, instance=answer)
        if form.is_valid():
            answer = form.save(commit=False)
            answer.modify_date = timezone.now()
            answer.save()
            #return redirect('testcarapp:detail', question_id=answer.question.id)
            return redirect('{}#answer_{}'.format(
                resolve_url('testcarapp:reportdetail', question_id=answer.question.id), answer.id))
    else:
        form = report_AnswerForm(instance=answer)
    context = {'answer': answer, 'form': form}
    return render(request, 'testcarapp/report_answer_form.html', context)


@login_required(login_url='common:login')
def answer_delete(request, answer_id):
    """
    pybo 답변삭제
    """
    answer = get_object_or_404(report_Answer, pk=answer_id)
    if request.user != answer.author:
        messages.error(request, '삭제권한이 없습니다')
    else:
        answer.delete()
    return redirect('testcarapp:reportdetail', question_id=answer.question.id)

