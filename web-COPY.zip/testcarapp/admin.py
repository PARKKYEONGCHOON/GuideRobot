from pyexpat import model
from django.contrib import admin
from .models import Question
from .models import report_Question
#from .models import report_Image

# Register your models here.

#admin.site.register(Question)

class QuestionAdmin(admin.ModelAdmin):
    search_fields = ['subject']




admin.site.register(Question, QuestionAdmin)
admin.site.register(report_Question)