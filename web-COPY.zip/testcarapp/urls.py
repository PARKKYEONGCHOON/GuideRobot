from django.urls import path,include

from .views import base_views, map_View, question_views, answer_views, comment_views, vote_views, data_view, report_answer_views ,report_question_views, report_base_views, report_comment_views, report_vote_views, video_View, ride_view

app_name = 'testcarapp'
#app_name = 'turtleland'

urlpatterns = [
    # base_views.py
     path('',
          base_views.index, name='index'),
     path('<int:question_id>/',
          base_views.detail, name='detail'),
     
     path('report',
          base_views.report_index, name='reportindex'),
     path('report/<int:question_id>/',
          base_views.report_detail, name='reportdetail'),

     # question_views.py
     path('question/create/',
          question_views.question_create, name='question_create'),
     path('question/modify/<int:question_id>/',
          question_views.question_modify, name='question_modify'),
     path('question/delete/<int:question_id>/',
          question_views.question_delete, name='question_delete'),
     path('question/download/<int:question_id>', 
          question_views.question_fileDownload, name="question_download"),

     # answer_views.py
     path('answer/create/<int:question_id>/',
          answer_views.answer_create, name='answer_create'),
     path('answer/modify/<int:answer_id>/',
          answer_views.answer_modify, name='answer_modify'),
     path('answer/delete/<int:answer_id>/',
          answer_views.answer_delete, name='answer_delete'),

     # comment_views.py
     path('comment/create/question/<int:question_id>/',
          comment_views.comment_create_question, name='comment_create_question'),
     path('comment/modify/question/<int:comment_id>/',
          comment_views.comment_modify_question, name='comment_modify_question'),
     path('comment/delete/question/<int:comment_id>/',
          comment_views.comment_delete_question, name='comment_delete_question'),
     path('comment/create/answer/<int:answer_id>/',
          comment_views.comment_create_answer, name='comment_create_answer'),
     path('comment/modify/answer/<int:comment_id>/',
          comment_views.comment_modify_answer, name='comment_modify_answer'),
     path('comment/delete/answer/<int:comment_id>/',
          comment_views.comment_delete_answer, name='comment_delete_answer'),
     
     # vote_views.py
     path('vote/question/<int:question_id>/', vote_views.vote_question, name='vote_question'),
     path('vote/answer/<int:answer_id>/', vote_views.vote_answer, name='vote_answer'),
     
     
     
     #report_base_view.py
     #path('report',
          #report_base_views.index, name='reportindex'),
     #path('report',
          #report_base_views.detail, name='reportdetail'),
     
     # report_question_views.py
     path('report_question/create/',
          report_question_views.question_create, name='report_question_create'),
     path('report_question/modify/<int:question_id>/',
          report_question_views.question_modify, name='report_question_modify'),
     path('report_question/delete/<int:question_id>/',
          report_question_views.question_delete, name='report_question_delete'),
     path('report_question/profile/',
          report_question_views.profile,name="profile"),
     
     
     # report_answer_views.py
     path('report_answer/create/<int:question_id>/',
         report_answer_views.answer_create, name='report_answer_create'),
     path('report_answer/modify/<int:answer_id>/',
         report_answer_views.answer_modify, name='report_answer_modify'),
     path('report_answer/delete/<int:answer_id>/',
         report_answer_views.answer_delete, name='report_answer_delete'),
    
    
    
    # report_comment_views.py
     path('report_comment/create/question/<int:question_id>/',
         report_comment_views.comment_create_question, name='report_comment_create_question'),
     path('report_comment/modify/question/<int:comment_id>/',
         report_comment_views.comment_modify_question, name='report_comment_modify_question'),
     path('report_comment/delete/question/<int:comment_id>/',
         report_comment_views.comment_delete_question, name='report_comment_delete_question'),
     path('report_comment/create/answer/<int:answer_id>/',
         report_comment_views.comment_create_answer, name='report_comment_create_answer'),
     path('report_comment/modify/answer/<int:comment_id>/',
         report_comment_views.comment_modify_answer, name='report_comment_modify_answer'),
     path('report_comment/delete/answer/<int:comment_id>/',
         report_comment_views.comment_delete_answer, name='report_comment_delete_answer'),
    
    # report_vote_views.py
     path('report_vote/question/<int:question_id>/', report_vote_views.vote_question, name='report_vote_question'),
     path('report_vote/answer/<int:answer_id>/', report_vote_views.vote_answer, name='report_vote_answer'),
    
#     # data_view.py
#      path('direction',
#          data_view.index, name='dataindex'),
     
     # data_view.py
     path('direction/<str:room_name>/',
         data_view.index, name='dataindex'),
     
     
     path('direction/<str:room_name>/<str:ride_id>/',data_view.ride_detail, name='ride_detail'), 
    
     path('direction/<str:room_name>/<str:ride_id>/coment',data_view.commentWrite, name='ride_comment_write'),
     path('direction/<str:room_name>/<str:ride_id>/<str:comment_id>',data_view.commentDelete, name='ride_comment_delete'),
     # path('LiveChat/',
     #     LiveVideo_View.index, name='live_video_index'),
    
    #map_view.py
     path('map/',
         map_View.index, name='map_index'),
     
     
     
     #video_view.py
     path('video/', video_View.index, name='videoindex'),

     #access the laptop camera
     path('video/video_feed', video_View.video_feed, name='video_feed'),

     #access the phone camera
     path('video/webcam_feed', video_View.webcam_feed, name='webcam_feed'),

    
    
    
    
]
