# chat/routing.py
from django.urls import re_path

from Ros.RosConsumer import RosConsumer

websocket_urlpatterns = [
    re_path(r'ws/testcarapp/(?P<room_name>\w+)/$', RosConsumer),
    #re_path(r'testcarapp/LiveChat\w+)/$', RosConsumer),
    
]
