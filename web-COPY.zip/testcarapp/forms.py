from django import forms
from testcarapp.models import Question, Answer, Comment, report_Answer, report_Comment, report_Question


class QuestionForm(forms.ModelForm):
    class Meta:
        model = Question  # 사용할 모델
        exclude = ['file']
        fields = ['subject', 'content','image','file']  # QuestionForm에서 사용할 Question 모델의 속성
        #widgets = {
            #'subject': forms.TextInput(attrs={'class': 'form-control'}),
            #'content': forms.Textarea(attrs={'class': 'form-control', 'rows': 10}),
        #}
        labels = {
            'subject': '제목',
            'content': '내용',
        } 
        
        upload = forms.FileField(label='첨부 파일', required=False, 
          widget=forms.FileInput(attrs={'class': 'form'}))
        
        
class AnswerForm(forms.ModelForm):
    class Meta:
        model = Answer
        fields = ['content']
        labels = {
            'content': '답변내용',
        }
        
class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ['content']
        labels = {
            'content': '댓글내용',
        }
        
class report_QuestionForm(forms.ModelForm):
    class Meta:
        model = report_Question  # 사용할 모델
        fields = ['subject', 'content', 'image']  # QuestionForm에서 사용할 Question 모델의 속성
        #widgets = {
            #'subject': forms.TextInput(attrs={'class': 'form-control'}),
            #'content': forms.Textarea(attrs={'class': 'form-control', 'rows': 10}),
        #}
        labels = {
            'subject': '제목',
            'content': '내용',
            
        } 
        
        
        
class report_AnswerForm(forms.ModelForm):
    class Meta:
        model = report_Answer
        fields = ['content']
        labels = {
            'content': '답변내용',
        }
        
class report_CommentForm(forms.ModelForm):
    class Meta:
        model = report_Comment
        fields = ['content']
        labels = {
            'content': '댓글내용',
        }                  