from django.apps import AppConfig


class TestcarappConfig(AppConfig):
    #default_auto_field = 'django.db.models.BigAutoField'
    name = 'testcarapp'
