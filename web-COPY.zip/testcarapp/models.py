from django.db import models
from django.contrib.auth.models import User

import os
# Create your models here.

class Question(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='author_question')
    subject = models.CharField(max_length=200)
    content = models.TextField()
    create_date = models.DateTimeField()
    modify_date = models.DateTimeField(null=True, blank=True)
    voter = models.ManyToManyField(User, related_name='voter_question')  # 추천인 추가
    image = models.ImageField(upload_to='images/',null = True, blank = True)
    file = models.FileField(upload_to='files/',null = True, blank = True)
    filename = models.CharField(max_length=64, null=True)

    def __str__(self):
        return self.subject
    
    def get_filename(self):
        return os.path.basename(self.file.name)
    
    
class Answer(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='author_answer')
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    content = models.TextField()
    create_date = models.DateTimeField()
    modify_date = models.DateTimeField(null=True, blank=True)
    voter = models.ManyToManyField(User, related_name='voter_answer')
    
class Comment(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField()
    create_date = models.DateTimeField()
    modify_date = models.DateTimeField(null=True, blank=True)
    question = models.ForeignKey(Question, null=True, blank=True, on_delete=models.CASCADE)
    answer = models.ForeignKey(Answer, null=True, blank=True, on_delete=models.CASCADE)
    

class report_Question(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='author_report_question')
    subject = models.CharField(max_length=200)
    content = models.TextField()
    create_date = models.DateTimeField()
    modify_date = models.DateTimeField(null=True, blank=True)
    voter = models.ManyToManyField(User, related_name='voter_report_question')  # 추천인 추가
    image = models.ImageField(upload_to='images/',null = True, blank = True)

    def __str__(self):
        return self.subject
    
class report_Answer(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='author_report_answer')
    question = models.ForeignKey(report_Question, on_delete=models.CASCADE)
    content = models.TextField()
    create_date = models.DateTimeField()
    modify_date = models.DateTimeField(null=True, blank=True)
    voter = models.ManyToManyField(User, related_name='voter_report_answer')
    
class report_Comment(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField()
    create_date = models.DateTimeField()
    modify_date = models.DateTimeField(null=True, blank=True)
    question = models.ForeignKey(report_Question, null=True, blank=True, on_delete=models.CASCADE)
    answer = models.ForeignKey(report_Answer, null=True, blank=True, on_delete=models.CASCADE)
    
#class report_Image(models.Model):
    
    #post = models.ForeignKey(report_Question,on_delete=models.CASCADE, null= True)
    #image = models.ImageField(upload_to='images/',null = True, blank = True)
    
class Ride(models.Model):
    #id
    name = models.CharField(max_length=255, blank=False, null=False)
    thumbnail = models.CharField(max_length=1000) 
    detail = models.CharField(max_length=255, blank=False, null=False, default='')
    explain = models.CharField(max_length=255, blank=False, null=False)
    height = models.CharField(max_length=255, blank=False, null=False) 
    #distance = models.CharField(max_length=10) #999999.9km
    rating = models.CharField(max_length=3)
    #desc = models.TextField(blank=True, null=False,default='')
    color = models.CharField(max_length=255, blank=False, null=False, default='') #6/15
    createTime = models.DateTimeField(auto_now_add=True)
    modifyTime = models.DateTimeField(auto_now=True)

    def __str__(self) ->str:
        return f'({self.pk}){self.name}' 
        



class RideComment(models.Model):   #댓글
    #CASCADE 참조하고 있는 레코드에 종속적으로 수정,삭제
    # row(레코드) 하나의 의미있는 집단
    # col 하나의 항목
    ride = models.ForeignKey(Ride, on_delete=models.CASCADE)
    authorName = models.CharField(max_length=255, blank=False, null=False)
    authorThumbnail = models.CharField(max_length=1000) #이미지 주소값
    message = models.CharField(max_length=1000)
    rating = models.CharField(max_length=3)

    # desc = models.TextField(max_length=255, blank=False, null=False)
    createTime = models.DateTimeField(auto_now_add=True)
    modifyTime = models.DateTimeField(auto_now=True)
    # createTime = models.DateTimeField('date create_time')
    # modifyTime = models.DateTimeField('date modify_time')

    def __str__(self) ->str:
            return f'({self.pk})[{self.ride}]' 
    